<?php
header('Content-Type: application/json');
include 'koneksi.php'; // Pastikan path ini benar untuk koneksi database Anda

$response = array();

if (isset($_GET['id_order'])) {
    $id_order = $_GET['id_order'];

    // Query untuk mengambil detail pesanan dari tbl_order
    $query_order = "SELECT * FROM tbl_order WHERE id_order = ?";
    $stmt_order = $conn->prepare($query_order);
    $stmt_order->bind_param("i", $id_order);
    $stmt_order->execute();
    $result_order = $stmt_order->get_result();

    if ($result_order->num_rows > 0) {
        $order_data = $result_order->fetch_assoc();

        // Mengambil detail produk dari tbl_order_detail dan tbl_product
        $query_products = "SELECT od.kode_product, od.harga_satuan, od.qty, p.merk, p.foto
                           FROM tbl_order_detail od
                           JOIN tbl_product p ON od.kode_product = p.kode
                           WHERE od.id_order = ?";
        $stmt_products = $conn->prepare($query_products);
        $stmt_products->bind_param("i", $id_order);
        $stmt_products->execute();
        $result_products = $stmt_products->get_result();

        $products = array();
        while ($row = $result_products->fetch_assoc()) {
            $products[] = $row;
        }

        $response['status'] = "sukses";
        $response['id_order'] = $order_data['id_order'];
        $response['tgl_order'] = $order_data['tgl_order'];
        $response['total_bayar'] = $order_data['total_bayar'];
        $response['status_order'] = $order_data['status']; // Menggunakan status dari tbl_order
        $response['bukti_bayar'] = $order_data['bukti_bayar'];
        $response['alamat_kirim'] = $order_data['alamat_kirim'];
        $response['telp_kirim'] = $order_data['telp_kirim'];
        $response['kurir'] = $order_data['kurir'];
        $response['service'] = $order_data['service'];
        $response['ongkir'] = $order_data['ongkir'];
        $response['products'] = $products;

    } else {
        $response['status'] = "gagal";
        $response['message'] = "Detail pesanan tidak ditemukan.";
    }

    $stmt_order->close();
    $stmt_products->close();
} else {
    $response['status'] = "gagal";
    $response['message'] = "ID Pesanan tidak diberikan.";
}

echo json_encode($response);
$conn->close();
?>